export type MoodType = {
  id :number,
  label:string,
  color:string,
  emoji:string
}
