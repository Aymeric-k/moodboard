export type SmartTag = 'lateNight' | 'lowEnergy' | 'withFriend';

export const SMART_TAGS: SmartTag[] = ['lowEnergy', 'lateNight', 'withFriend'];

