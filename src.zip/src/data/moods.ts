export const moods = [
  { id: 1, label: "Happy", color: "bg-yellow-300", emoji: "😊" },
  { id: 5, label: "Relaxed", color: "bg-teal-400", emoji: "😌" },
  { id: 6, label: "Motivated", color: "bg-orange-400", emoji: "🔥" },
  { id: 7, label: "Curious", color: "bg-indigo-400", emoji: "🤔" },
  { id: 2, label: "Tired", color: "bg-blue-300", emoji: "😴" },
  { id: 3, label: "Angry", color: "bg-red-400", emoji: "😡" },
  { id: 4, label: "Sad", color: "bg-slate-500", emoji: "😔" },
]
